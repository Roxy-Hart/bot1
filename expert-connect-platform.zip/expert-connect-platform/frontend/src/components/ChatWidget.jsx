import React, { useEffect } from 'react';

const ChatWidget = () => {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = "https://cdn.botpress.cloud/webchat/v0/inject.js";
    script.async = true;
    document.body.appendChild(script);

    script.onload = () => {
      window.botpressWebChat.init({
        "botId": "your-bot-id",
        "clientId": "your-client-id",
        "hostUrl": "https://cdn.botpress.cloud/webchat/v0",
        "messagingUrl": "https://messaging.botpress.cloud",
        "containerWidth": "100%",
        "layoutWidth": "100%",
        "enableReset": true,
        "showPoweredBy": false,
      });
    };
  }, []);

  return (
    <div>
      <h2>Chat with us</h2>
      {/* Botpress webchat will inject here */}
    </div>
  );
};

export default ChatWidget;
