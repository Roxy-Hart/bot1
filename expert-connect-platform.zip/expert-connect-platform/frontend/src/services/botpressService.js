import axios from 'axios';

const BOTPRESS_API = "https://api.botpress.cloud/v1/bots/your-bot-id/converse";

export const sendMessageToBot = async (userId, message) => {
  const response = await axios.post(`${BOTPRESS_API}/${userId}`, {
    type: "text",
    text: message,
  }, {
    headers: {
      Authorization: `Bearer your-client-token`
    }
  });

  return response.data;
};
