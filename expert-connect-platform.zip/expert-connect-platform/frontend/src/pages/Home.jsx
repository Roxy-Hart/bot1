import React from 'react';
import ChatWidget from '../components/ChatWidget';

const Home = () => {
  return (
    <div className="h-screen w-screen flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-8">Welcome to Expert Connect</h1>
      <ChatWidget />
    </div>
  );
};

export default Home;
