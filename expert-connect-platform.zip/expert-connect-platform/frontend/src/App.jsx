import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import ProjectView from './pages/ProjectView';
import ExpertSearch from './pages/ExpertSearch';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/project" element={<ProjectView />} />
        <Route path="/search" element={<ExpertSearch />} />
      </Routes>
    </Router>
  );
}

export default App;
