from fastapi import APIRouter, Request
from services import twilio

router = APIRouter(prefix="/whatsapp", tags=["WhatsApp Handler"])

@router.post("/receive")
async def receive_whatsapp_message(request: Request):
    data = await request.form()
    message_sid = data.get('MessageSid')
    from_number = data.get('From')
    body = data.get('Body')

    await twilio.process_whatsapp_message(from_number, body)
    return {"status": "Received"}
