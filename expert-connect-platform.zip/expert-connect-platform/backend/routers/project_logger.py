from fastapi import APIRouter
from services import sheets

router = APIRouter(prefix="/project", tags=["Project Logger"])

@router.post("/log")
async def log_project(project_data: dict):
    await sheets.save_project_to_sheet(project_data)
    return {"status": "Project logged successfully"}
