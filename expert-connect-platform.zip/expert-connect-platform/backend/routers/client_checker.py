from fastapi import APIRouter
from services import sheets

router = APIRouter(prefix="/client", tags=["Client Checker"])

@router.post("/check")
async def check_client(email: str = None, phone: str = None):
    result = await sheets.check_client_in_sheet(email, phone)
    return {"is_client": result}
