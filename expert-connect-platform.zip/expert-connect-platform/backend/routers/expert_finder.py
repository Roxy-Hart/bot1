from fastapi import APIRouter
from services import zoho

router = APIRouter(prefix="/experts", tags=["Expert Finder"])

@router.post("/find")
async def find_experts(project_focus: str, countries: list, companies: list):
    experts = await zoho.find_matching_experts(project_focus, countries, companies)
    return {"experts": experts}
