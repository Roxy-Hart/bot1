import gspread
from oauth2client.service_account import ServiceAccountCredentials

# Setup
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("path/to/your/credentials.json", scope)
client = gspread.authorize(creds)

# Functions
async def check_client_in_sheet(email: str, phone: str):
    sheet = client.open("ClientDatabase").worksheet("Clients")
    records = sheet.get_all_records()
    for record in records:
        if email and record['email'].lower() == email.lower():
            return True
        if phone and record['phone'] == phone:
            return True
    return False

async def save_project_to_sheet(project_data: dict):
    sheet = client.open("ClientDatabase").worksheet("Projects")
    sheet.append_row(list(project_data.values()))
