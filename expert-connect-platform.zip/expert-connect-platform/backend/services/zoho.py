import requests

ZOHO_ACCESS_TOKEN = "your_zoho_access_token"

async def find_matching_experts(project_focus: str, countries: list, companies: list):
    url = "https://recruit.zoho.com/recruit/v2/Candidates/search"
    headers = {
        "Authorization": f"Zoho-oauthtoken {ZOHO_ACCESS_TOKEN}"
    }
    params = {
        "criteria": f"(Current_Company:equals:{companies[0]})"  # basic example
    }
    response = requests.get(url, headers=headers, params=params)
    experts = response.json()
    return experts
