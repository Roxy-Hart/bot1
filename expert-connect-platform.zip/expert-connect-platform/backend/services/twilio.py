from twilio.rest import Client

# Twilio credentials
account_sid = 'your_account_sid'
auth_token = 'your_auth_token'
client = Client(account_sid, auth_token)

async def process_whatsapp_message(from_number: str, body: str):
    print(f"Received message from {from_number}: {body}")

async def send_whatsapp_message(to_number: str, body: str):
    message = client.messages.create(
        from_='whatsapp:your_twilio_whatsapp_number',
        body=body,
        to=f'whatsapp:{to_number}'
    )
    return message.sid
