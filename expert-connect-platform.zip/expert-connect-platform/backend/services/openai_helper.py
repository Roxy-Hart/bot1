import openai

openai.api_key = "your_openai_api_key"

async def suggest_companies_from_focus(project_focus: str, country: str):
    prompt = f"Suggest 25 companies in {country} related to {project_focus}."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    companies = response['choices'][0]['message']['content']
    return companies
