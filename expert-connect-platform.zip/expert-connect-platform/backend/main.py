from fastapi import FastAPI
from routers import client_checker, expert_finder, project_logger, whatsapp_handler

app = FastAPI()

# Include routers
app.include_router(client_checker.router)
app.include_router(expert_finder.router)
app.include_router(project_logger.router)
app.include_router(whatsapp_handler.router)

@app.get("/")
async def root():
    return {"message": "Expert Connect Backend is running 🚀"}
