const axios = require('axios');

async function fetchExperts(state, event) {
  const focus = state.projectFocus;
  const res = await axios.post('https://your-backend-domain.com/experts/find', {
    project_focus: focus,
    countries: [],
    companies: []
  });

  return { expertList: res.data.experts.map(e => `${e.current_company} - ${e.current_title}`).join('\n') };
}

return fetchExperts;
