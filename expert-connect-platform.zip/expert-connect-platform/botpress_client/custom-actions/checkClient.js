const axios = require('axios');

async function checkClient(state, event) {
  const email = event.payload.text;
  
  const res = await axios.post('https://your-backend-domain.com/client/check', { email });

  return { isClient: res.data.is_client };
}

return checkClient;
