const axios = require('axios');

async function saveProject(state, event) {
  const projectData = {
    client_id: state.clientId,
    project_subject: state.projectSubject,
    focus_area: state.projectFocus,
    geographies: state.geographies,
    screening_questions: state.screeningQuestions
  };

  await axios.post('https://your-backend-domain.com/project/log', projectData);

  return state;
}

return saveProject;
