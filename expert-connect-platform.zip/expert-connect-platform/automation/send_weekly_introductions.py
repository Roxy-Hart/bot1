from services import sheets, zoho, openai_helper
import asyncio

async def send_weekly_expert_intros():
    clients = await sheets.get_active_clients()

    for client in clients:
        focus = client['focus_area']
        country = client['country']

        experts = await zoho.find_matching_experts(focus, [country], [])
        
        # Prepare and send intro message
        message = f"Hi {client['name']}, here are some new experts based on your interests:\n"
        for expert in experts[:5]:
            message += f"- {expert['current_company']} ({expert['current_title']}) - {expert['country']}\n"

        await sheets.log_introduction(client, experts[:5])
        await twilio.send_whatsapp_message(client['phone'], message)

if __name__ == "__main__":
    asyncio.run(send_weekly_expert_intros())
