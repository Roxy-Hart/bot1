from services import sheets, twilio
import asyncio

async def send_reminders():
    pending_projects = await sheets.get_pending_projects()

    for project in pending_projects:
        phone_number = project['client_phone']
        message = f"Reminder: Please review the expert profiles shared for your project '{project['project_subject']}'."
        await twilio.send_whatsapp_message(phone_number, message)

if __name__ == "__main__":
    asyncio.run(send_reminders())
