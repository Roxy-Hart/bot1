from services import sheets, twilio
import asyncio

async def auto_call_unresponsive_experts():
    experts = await sheets.get_unresponsive_experts()

    for expert in experts:
        phone = expert['phone']
        message = "Hi, this is Silverlink AI. You have been invited to a project. Please check your email and reply."
        await twilio.send_whatsapp_message(phone, message)  # Or initiate a voice call if using a call API

if __name__ == "__main__":
    asyncio.run(auto_call_unresponsive_experts())
