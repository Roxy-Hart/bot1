from services import sheets
import asyncio

async def log_conversation(client_id, channel, content):
    conversation = {
        "client_id": client_id,
        "channel": channel,
        "content": content
    }
    await sheets.save_conversation_log(conversation)

if __name__ == "__main__":
    print("This script is meant to be imported by other services.")
