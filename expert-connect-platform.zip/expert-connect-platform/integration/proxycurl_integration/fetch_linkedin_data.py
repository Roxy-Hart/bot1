import requests

PROXYCURL_API_KEY = "your_proxycurl_key"

def get_linkedin_profile(linkedin_url):
    headers = {
        "Authorization": f"Bearer {PROXYCURL_API_KEY}"
    }
    params = {
        "linkedin_profile_url": linkedin_url,
        "use_cache": "if-present"
    }

    response = requests.get("https://nubela.co/proxycurl/api/v2/linkedin", headers=headers, params=params)
    
    if response.status_code == 200:
        return response.json()
    return None
