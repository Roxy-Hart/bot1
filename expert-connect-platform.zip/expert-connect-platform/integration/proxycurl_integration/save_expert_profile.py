import json
import os

def save_expert_profile(profile_data, output_dir="output_profiles"):
    os.makedirs(output_dir, exist_ok=True)
    filename = f"{profile_data['name'].replace(' ', '_')}.json"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w') as f:
        json.dump(profile_data, f, indent=2)
