from .fetch_linkedin_data import get_linkedin_profile

def match_expert_to_keywords(linkedin_url, keywords):
    profile = get_linkedin_profile(linkedin_url)
    if not profile:
        return False

    experience = profile.get("experience", [])
    for job in experience:
        for keyword in keywords:
            if keyword.lower() in job.get("title", "").lower():
                return True
    return False
