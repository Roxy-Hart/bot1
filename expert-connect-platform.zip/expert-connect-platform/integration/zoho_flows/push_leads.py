import requests

ZOHO_TOKEN = "your_oauth_token"
ZOHO_ENDPOINT = "https://creator.zoho.com/api/v2/yourapp/form/Experts/formData"

def push_expert_to_zoho(data):
    headers = {
        "Authorization": f"Zoho-oauthtoken {ZOHO_TOKEN}",
        "Content-Type": "application/json"
    }

    payload = {
        "data": {
            "Expert_Name": data["name"],
            "Company": data["company"],
            "Title": data["title"],
            "Email": data["email"],
            "Phone": data["phone"],
            "LinkedIn": data["linkedin"],
        }
    }

    response = requests.post(ZOHO_ENDPOINT, json=payload, headers=headers)
    return response.json()
