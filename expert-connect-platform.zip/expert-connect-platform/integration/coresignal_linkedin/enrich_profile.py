import requests

CORESIGNAL_API_KEY = "your_api_key"

def fetch_profile_from_coresignal(full_name, company=None, location=None):
    query = {
        "full_name": full_name,
        "company": company,
        "location": location
    }

    headers = {
        "X-API-Key": CORESIGNAL_API_KEY
    }

    response = requests.get("https://api.coresignal.com/linkedin/profiles", params=query, headers=headers)

    if response.status_code == 200:
        return response.json()  # May return multiple candidates
    return None
